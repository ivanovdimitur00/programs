#include <iostream>
#include <cstring>
char words[60][18];


void make_string_with_exception(char words[][18],int rows, char* word,char* string) {
    for (int i = 0; i < rows; i++) {
        if (! strcmp(words[i],word)) {
            strcat(string,words[i]);
            strcat(string,(const char*)' ');
        }
    }
}

void substitute(char* word, char* replacement) {
    for (int i = 0; i < strlen(replacement); i++){
            word[i] = replacement[i];
    }
    word[strlen(replacement)] = '0';
}

void make_string_with_replacement(char words[][18],int rows, char* oldWord, char* newWord ,char* string) {
    for (int i = 0; i < rows; i++) {
        if (strcmp(words[i],oldWord)) {
            substitute(words[i],newWord);
            strcat(string,words[i]);
            strcat(string,(const char*)' ');
        } else {
            strcat(string,words[i]);
            strcat(string,(const char*)' ');
        }
    }
}

void print_string (char* string){
    std::cout << string << std::endl;
}

void my_remove (char* source, char* word) {

    
    int index_row = 0;
    int index_len = 0;
    char symbol = source[strlen(source)] - 1;

    for (int i = 0; i < strlen(source) - 1; i++) {
        if (source[i] != ' ' || source[i] !='.' || source[i] !='!' || source[i] !='?') {
            words[index_row][index_len] = source[i];
            index_len++;
        } else {
            index_row++;
            index_len = 0;
        }
    }

    char string[256];
    make_string_with_exception(words,index_row,word,string);
    string[strlen(string)] = symbol;
    string[strlen(string)] = '0';
    print_string(string);
}

void replace (char* source, char* oldWord, char* newWord) {

    int index_row = 0;
    int index_len = 0;
    char symbol = source[strlen(source)] - 1;

    for (int i = 0; i < strlen(source) - 1; i++) {
        if (source[i] != ' ' || source[i] !='.' || source[i] !='!' || source[i] !='?') {
            words[index_row][index_len] = source[i];
            index_len++;
        } else {
            index_row++;
            index_len = 0;
        }
    }

    char string[273];
    make_string_with_replacement(words,index_row,oldWord,newWord,string);
    string[strlen(string)] = symbol;
    string[strlen(string)] = '0';
    print_string(string);
}


int main()
{
    //1 част - remove

    char source[256];
    // char word[18];


    std::cin.getline(source,256);
    // std::cin>> word;

    // my_remove (source,word); // remove е заето;
    

//   ----------------------------------------
//    2 част - replace

    char oldWord[18];
    char newWord[18];

    std::cin>> oldWord;
    std::cin>> newWord;

    replace (source,oldWord,newWord);
   

    return 0;
}